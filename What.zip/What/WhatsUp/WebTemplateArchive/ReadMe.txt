WhatsUp Gold

This "WebTemplateArchive" folder simply contains a read only "backup 
set" of the latest installs web files.  You can use these files
to recover from any errors during changes and customizations
you may have made in your working "Web" directory.  Since this is
just a backup or original files you should not work directly out of this
folder.

Whenever a new version of WhatsUp Gold is installed, this directory
will be refreshed to the most current web template files.

If you have customized your own web files in the "Web" directory, then
the install will detect these changes and prompt you to determine if
you would like to keep your custom set or replace it with the latest
web files.  If you opt to replace your set then the install will backup
your set into a subdirectory under the "WebTemplateArchive" folder.  It is 
then up to you to merge your customizations back into the "Web" folder as 
you desire.

The "Classic" set of web files in this folder is the classic web interface 
found in WhatsUp Version 5 and 6 and is the default "look" of the web 
interface for Version 7 & 8.

This "WebTemplateArchive" directory is just a convenient backup of the 
original web files.  The "Web" directory is the working copy.








