/******************************************************************************
  WUGAPI.h
  Copyright (c) 1999 - Ipswitch, Inc.
******************************************************************************/

#ifndef _WUGAPI_H_
#define _WUGAPI_H_

/******************************************************************************
*******************************************************************************
## COM OBJECT IMPLEMENTATION

  You MUST mark your object with the Single Threaded Apartment model.
  You MUST make your object thread safe as only one instance of the com 
     object will be created and many threads may access it concurrently
     in a contradiction of the rules of the STA.  However, as this runs
     in-process, it is acceptable as long as your object is thread safe.
      
  ->ONLY ONE COPY OF YOUR COM OBJECT IS CREATED FOR USE BY ALL THREADS<-

##USAGE:

  Load: reads the attributes in from services.ini to populate the values of an 
        instance.

  Save: write the current plugin attribute values to the services.ini file. *IT 
        IS REQUIRED that the instance name be the ini section name and that the 
        CLSID of the dll be written to a key named CLSID.

  GetTypeName: gets the typename of the plugin

  SetName: sets the name of the instance of the plugin

  CheckService: performs the service check operation.  the ip address of the
                host to be checked is passed in.

  UpdateData: forces the plugins property sheet data to update.

  DisplayPropSheet: creates a child dialog inside of the given HWND for user
                    input of instance values.

  DestroyPropSheet: called by WUG to close the property sheet.

  CallWinHelp: Calls the helpfile for a specified help index.

  SetDebugWndHandle: called by WUG to provide a window handle that can be
                     used to display messages in the WUG debug window.  Proper
                     method of using this window handle is:
                     if(h && IsWindow(h))
                        { SendMessage(h,WM_USER+3,0,(LPARAM)(LPCSTR)s); }
******************************************************************************/


typedef enum WhatHostInfo
{
  HI_WhatNull=0,
  HI_WhatDisplayName,
  HI_WhatHostName,
  HI_WhatAddress,
  HI_WhatInfo1,
  HI_WhatInfo2,
  HI_WhatCommunity,
  HI_dwWhatTimeout, 
  HI_dwWhatDelay,
  HI_dwUser1,
  HI_dwUser2,
  HI_dwUser3,
  HI_WhatCustomArgument,// WUG7: Argument string specific to this plugin and specific to this monitor on this device
  HI_dwGetBlob,			// WUG7: a get function that returns a void pointer in a DWORD to blob of memory specific to this monitor on this device
  HI_dwReallocBlob,		// WUG7: a set function that reallocs the blob to a new size
  HI_dwFreeBlob,		// WUG7: a set function that frees all memory in the blob (dwData value is ignored, no worries WUG will cleanup if you dont)
  HI_dwGetBlobSize,		// WUG7: a get function that returns the size of the allocated blob
  HI_WhatNotes			// WUG8: Used to get and set the notes field on a host
};

//  HI_dwUser1-3 are plugin usable storage areas

class IWugHostInfo
{
public:
  virtual HRESULT SetInfo(int nWhat, BSTR bstrData)=0;
  virtual HRESULT SetInfo(int nWhat, long dwData)=0;
  virtual HRESULT GetInfo(int nWhat, BSTR* bstrData)=0;
  virtual HRESULT GetInfo(int nWhat, long* dwData)=0;
  virtual LPCSTR GetAddress()=0;
  virtual void SetReturnCode(long lRetCode)=0;
  virtual void SetTime(long lTimeToProcess)=0;
	virtual HRESULT SetLastErrorString(BSTR bstrError)=0;
};

// NOTE: you must call delete on any string
// returned by "GetInfo(int nWhat, BSTR * bstrData);" and 
// on any strings allocated for SetInfo.

// Your CheckService implementation should measure the time (in
// ticks) and return the time for the check by calling
// IWugHostInfo->SetTime(dwTicks)

// Your CheckService should also return a last error message
// string with IWugHostInfo->SetLastErrorString(bstrError);

// Note the value returned by GetAddress may actually be a
// host name and not an IP address.

//  GetAddress is equivalent to GetInfo(HI_WhatAddress,....)

// minimum expectation of CheckService is
/*
    // Returns: *lRetcode == 0 if the "service" is considered
    // up and non-zero if down.  The *lRetcode could be standard
    // error codes or whatever you desire.
    HRESULT Plugin::CheckService(IWugHostInfo* pWHI,long *lRetcode)
    {
       DWORD dwTickCount = GetTickCount();
       long result=do_some_check_on(pWHI->GetAddress());
       // set response time
       pWHI->SetTime(dwTickCount-GetTickCount());

       BSTR bstr;
       if(result)
       {
          bstr = SysAllocString(OLESTR("check OK\r\n"));
          pWHI->SetLastErrorString(bstr);
          *lRetcode=0;
       } else
       {
          bstr = SysAllocString(OLESTR("check failed\r\n"));
          pWHI->SetLastErrorString(bstr);
          *lRetcode=1;
       }
       pWHI->SetReturnCode(*lRetcode);
       SysFreeString(bstr);
       return S_OK;
    }
*/

#undef  INTERFACE
#define INTERFACE   IWUGSvcObj

// {CE6DCF10-1AAA-11d3-ACF2-0020AF10AA31}
DEFINE_GUID(IID_IWUGSvcObj, 
0xce6dcf10, 0x1aaa, 0x11d3, 0xac, 0xf2, 0x0, 0x20, 0xaf, 0x10, 0xaa, 0x31);

DECLARE_INTERFACE_(IWUGSvcObj, IUnknown) 
{
  // IUnknown members
  STDMETHOD (QueryInterface)      (THIS_ REFIID, LPVOID FAR *) PURE;
  STDMETHOD_(ULONG,AddRef)        (THIS) PURE;
  STDMETHOD_(ULONG,Release)       (THIS) PURE;

  // IWUGSvcObj members
  STDMETHOD (Load)                (THIS_ LPCOLESTR) PURE;
  STDMETHOD (Save)                (THIS_ LPCOLESTR) PURE;
  STDMETHOD (GetTypeName)         (THIS_ BSTR*) PURE;
  STDMETHOD (SetName)             (THIS_ BSTR) PURE;
  STDMETHOD (CheckService)        (IWugHostInfo*, long*) PURE;
  STDMETHOD (UpdateData)          (THIS_ long) PURE;
  STDMETHOD (DisplayPropSheet)    (THIS_ long) PURE;
  STDMETHOD (DestroyPropSheet)    (void) PURE;
  STDMETHOD (CallWinHelp)         (THIS_ long) PURE;
  STDMETHOD (SetDebugWndHandle)   (THIS_ long) PURE;
};

typedef IWUGSvcObj *PIWUGSVCOBJ;

/******************************************************************************
******************************************************************************/
#endif
